package com.example.myapplication

data class User(val  name: String, val address: String)